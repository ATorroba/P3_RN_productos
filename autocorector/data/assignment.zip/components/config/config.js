const CONFIG = {
  server_url: "https://dummyjson.com/products",
  num_items: 30,
  use_server: true,
  loading_timeout_ms: 500,
}

export default CONFIG;